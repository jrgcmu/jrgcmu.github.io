# This file creates sample data for the examples in 
# "How to do stuff in R and Stata" and exports
# them to CSV files to be imported in the R and Stata
# example scripts

# generate the data -------------------------------------------------------

# seed random number generator
set.seed(8675309)

# blank data frame with id
df <- data.frame(id=1:10)

# v1 and v2 that uniquely identify observations
df$v1 <- ceiling(df$id/2)
df$v2 <- rep(1:2, 5)

# time varying variables
for (i in 1:2) {
  df[, paste0("x",i)] <- rnorm(10)
  df[, paste0("y", i)] <- rnorm(10)
}

# categorical variable
df$z <- sample(1:4, 10, replace=TRUE)

new.dat <- data.frame(id=1:10)
new.dat$v1 <- ceiling(df$id/2)
new.dat$v2 <- rep(1:2, 5)
new.dat$w <- rnorm(10)

write.csv(df, "datafile1.csv")
write.csv(new.dat, "datafile2.csv")
