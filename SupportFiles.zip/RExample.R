# This file reads the data and runs through all of the examples in
# "How to do stuff in R and Stata"

library(tidyverse)

dat <- read_csv("datafile1.csv")

# drop.keep
dat[c("x1", "x2")]
dat[, c("x1", "x2")]
subset(dat, select=c(x1, x2))
dat[!(names(dat) %in% c("x1", "x2"))]
dat[-c(5,7)]
subset(dat, select=-c(x1, x2))
dat[!startsWith(names(dat),"x")]

dat |> select(x1, x2)
dat |> select(!c("x1", "x2"))
dat |> select(!starts_with("x"))

# subset
dat[dat$y1>=0 & dat$z!=2,]
subset(dat, y1 >= 0 & z!=2)

dat |> filter(y1 >= 0 & z!=2)

# rename
names(dat)[names(dat)=="y1"] <- "why1"
names(dat)[6] <- "why1"
names(dat)[names(dat) %in% c("y1", "x1")] <- c("why1", "ecks1")

dat |> rename(why1 = y1, ecks1 = x1)

# recoding ----------------------------------------------------------------

dat$x1[dat$x1>0] <- 1

dat |> mutate(x1 = replace(x1, x1>0, 1))

vars <- c("x1", "y1")
for (i in vars) {
  dat[dat[i]>0, i] <- 1
}

dat[vars][dat[vars]>0] <- 1

dat |> mutate(across(c(x1, y1), ~replace(., .>0, 1)))

# variations
dat |> mutate(across(num_range("x", 1:2), ~replace(., .>0, 1)))
dat |> mutate(across(starts_with(c("x", "y")), ~replace(., .>0, 1)))

# alternative syntax and variations
dat |> mutate(x1 = case_when(x1>0 ~ 1, TRUE ~ x1) )
dat |> mutate(across(c(x1,y1) , ~ case_when(.>0 ~ 1, TRUE ~ . ) ) )

dat$xsq <- dat$x1^2

vars <- c("x1", "x2")
for (i in seq_along(vars)) {
  dat[, paste0(vars[i], "sq")] <- dat[vars[i]]^2
}

dat[paste0(c("x1", "y1"),"sq")] <- dat[c("x1", "y1")]^2  

dat |> mutate(x1sq = x1^2)

# variations
dat |> mutate(across(c(x1,y1), .fns=list(sq=~ .x^2), .names="{col}_{fn}"))
dat |> mutate(across(num_range("x",1:2), .fns=list(sq=~ .x^2), .names="{col}_{fn}"))
dat |> mutate(across(starts_with("x"), .fns=list(sq=~ .x^2), .names="{col}_{fn}"))


# merge and reshape -------------------------------------------------------

# restore original data
dat <- read_csv("datafile1.csv")

new.dat <- read_csv("datafile2.csv")

merge(dat, new.dat, by="id")

dat |> left_join(new.dat, join_by(id))

merge(dat, new.dat, by=c("v1", "v2"))

dat |> left_join(new.dat, join_by(v1, v2))

# for some reason that reshape command won't work with the data imported from 
# read_csv unless you change it to an official dataframe
dat2 <- data.frame(dat)

long1 <- reshape(dat2, idvar="id", varying=c("x1", "x2", "y1", "y2"), sep="", 
                 direction="long")

long2 <- dat |> pivot_longer(cols=c("x1", "x2", "y1", "y2"), 
                             names_to=c(".value", "year"),
                             names_pattern = "([A-Za-z]+)(\\d+)")

reshape(long1, idvar="id", timevar="time", direction="wide", v.names=c("x", "y"))

pivot_wider(long2, names_from = "year", 
            values_from=c("x", "y"), names_glue ="{.value}_{year}")

# another way to do this
pivot_wider(long2, names_from="year", values_from=c("x", "y"), id_cols=c("id", "z", "v1", "v2"))

# do this with just one time-varying value (by default the names don't work
# in pivot_wider, so have to use the names_glue syntax, which can be omitted
# in other cases)
d2 <- dat |> select(!starts_with("y"))
long3 <- d2 |> pivot_longer(cols=c("x1", "x2"), 
                             names_to=c(".value", "year"),
                             names_pattern = "([A-Za-z]+)(\\d+)")
pivot_wider(long3, names_from = year, values_from=x, names_glue ="{.value}_{year}")


# aggregate ---------------------------------------------------------------

aggregate(y1 ~ v1 + v2, dat, mean)

dat |> group_by(v1, v2) |> summarize(mean(y1))

aggregate(cbind(y1, y2) ~ v1 + v2, dat, mean)

dat |> group_by(v1, v2) |> summarize(across(c("y1", "y2"), mean))

aggregate(cbind(y1, y2) ~ v1 + v2, dat, 
          \(x) c(mean = mean(x, na.rm=TRUE), 
                 median = median(x, na.rm=TRUE)))

dat |> group_by(v1, v2) |> summarize(across(c(y1, y2), 
  list(mean = \(x) mean(x, na.rm=TRUE),
  median = \(x) median(x, na.rm=TRUE))))

dat |> group_by(z) |> mutate(across(c(y1, y2), 
  list(mean = \(x) mean(x, na.rm=TRUE)), 
  .names="{col}_{fn}"))

dat[paste0(c("y1","y2"), "_mean")] <- 
  lapply(dat[c("y1", "y2")], 
  \(x) ave(x, dat$z, FUN=mean))

for (i in c("y1", "y2")) {
  dat[paste0(i,"_mean")] <- ave(dat[[i]], dat$z, FUN=mean)
}


# basic stats -------------------------------------------------------------

library(modelsummary)
datasummary_skim(dat)
datasummary_skim(dat[c("y1", "y2")])
datasummary_skim(by="z", data=dat)

prop.table(xtabs(~ v2 + z, dat), 1)
prop.table(table(dat$v2, dat$z), 1)

# just for fun, here is the somewhat insane way to do this in the tidyverse
# column sums
dat |> mutate(count=1) |> 
  pivot_wider(names_from=v2, values_from=count, values_fill=0,  names_glue = "v2_{v2}") |> 
  select(z, v2_1, v2_2) |>
  group_by(z) |> 
  summarize(v2_1=sum(v2_1)/(sum(v2_1 + v2_2)), v2_2=sum(v2_2)/(sum(v2_1+v2_2)))

# row sums
dat |> mutate(count=1) |> 
  pivot_wider(names_from=v2, values_from=count, values_fill=0,  names_glue = "v2_{v2}") |> 
  select(z, v2_1, v2_2) |> 
  mutate(v2_1_sum=sum(v2_1), v2_2_sum=sum(v2_2)) |>
  group_by(z) |> 
  summarize(v2_1=sum(v2_1)/first(v2_1_sum), v2_2=sum(v2_2)/first(v2_2_sum))

plot(dat$x1, dat$y1)
ggplot(dat, aes(x=x1, y=y1)) + geom_point()

hist(dat$y1)
ggplot(dat, aes(x=y1)) + geom_histogram()


# econometrics ------------------------------------------------------------

model1 <- lm(y1 ~ x1 + x2, data=dat)
summary(model1)

model2 <- lm(y1 ~ x1 + x2, data=dat[dat$z==1,])

model3 <- lm(y1 ~ x1 + x2 + as.factor(z), 
             data=dat)

model4 <- lm(y1 ~ x1 + I(x1^2) + x2, data=dat)

library(sandwich)
library(lmtest)
coeftest(model1, 
         vcov = vcovHC(model1, type="HC1"))

coeftest(model1, vcov=vcovCL(model1, 
                             cluster = ~z))

library(plm)
model5 <- plm(y ~ x,
              data=long1, model="within", index=c("id"))
coeftest(model5, 
         vcov=vcovHC(model5, type="HC2", cluster="group"))  

library(fixest)
model5b <- feols(y ~ x | id, cluster=~id, data=long2)

library(ivreg)
model6 <- ivreg(y1 ~ x1 + x2 | z + x2, data=dat)

library(margins)
dat$bin <- (dat$y1 > 0)
model7 <- glm(bin ~ x1 + x2, 
              family=binomial(link=probit), 
              data=dat)
probit_margins <- margins(model7)
summary(probit_margins)


# post estimation ---------------------------------------------------------

library(car)
linearHypothesis(model1, 
                 c("x1 = 0", "x2 = 0"))
linearHypothesis(model1, c("x1 = x2"))

model1$residuals

model1$fitted.values
predict(model1)

model1$coefficients
coef(model1)

sqrt(diag(vcov(model1)))
summary(model1)$coefficients[,2]

library(modelsummary)
modelsummary(list(model1, model2, model3))
modelsummary(list(model1, model2, model3), output="latex")
modelsummary(list(model1, model2, model3), output="markdown")
mod.sum <- modelsummary(list(model1, model2, model3), output="data.frame")

modelplot(model3, coef_omit="Interc.")


# programmery stuff ------------------------------------------------------------

models <- list()
for (i in as.factor(unique(dat$z))) {
  models[[i]] <- lm(y1 ~ x1 + x2, dat[dat$z==i,])
  print(summary(models[[i]]))
}

subreg <- function(var) {
  lm(y1 ~ x1 + x2, dat[dat$z==i,])
}
models <- lapply(unique(dat$z), subreg)
lapply(models, summary)

models <- lapply(unique(dat$z), function(i) lm(y1 ~ x1 + x2, dat[dat$z==i,]))
lapply(models, summary)

models <- lapply(unique(dat$z), \(i) lm(y1 ~ x1 + x2, dat[dat$z==i,]))
lapply(models, summary)

by(dat, dat$z, \(df) summary(lm(y1 ~ x1 + x2, df)))

# could also use tapply for this
tapply(dat, dat$z, \(df) summary(lm(y1 ~ x1 + x2, df)))

# could also use the split function
ds <- split(dat, dat$z)
lapply(ds, \(d) lm(y1 ~ x1, d))

dat |> split(dat$z) |> map(\(df) lm(y1 ~ x1, data=df)) |> map(summary)

lapply(split(dat, dat$z),
       \(df) summary(lm(y1 ~ x1, data=df)))

deps <- c("y1", "y2")
models <- list()
for (i in seq_along(deps)) {
  models[[i]] <- lm(paste0(deps[i], "~ x1 + x2"), data=dat)
}
lapply(models, summary)

lapply(
  paste0(deps, "~ x1 + x2"), lm, data=dat
)

lm(cbind(y1, y2) ~ x1 + x2, dat)

indeps <- c("x1", "x1 + x2")
models <- lapply(
  paste0("y1 ~", indeps), lm, data=dat
)

# just for fun, here is a tidyverse version
indeps |> map(\(x) lm(paste0("y1 ~",x), dat)) |> map(summary)
indeps |> map(~lm(paste0("y1 ~",.x), dat)) |> map(summary)



# viz ---------------------------------------------------------------------

# this is mostly copied from r4ds

library(palmerpenguins)

ggplot(
  data = penguins,
  mapping = aes(x = flipper_length_mm, y = body_mass_g)
) +
  geom_point(aes(color = species, shape = species)) +
  geom_smooth(method = "lm") +
  labs(
    x = "Flipper length (mm)", y = "Body mass (g)",
    color = "Species", shape = "Species"
  ) 

ggsave("rg1.pdf")

ggplot(penguins, aes(x = flipper_length_mm, y = body_mass_g)) +
  geom_point(aes(color = species, shape = species)) +
  facet_wrap(~island)

ggsave("rg2.pdf")

ggplot(penguins, aes(x = island, fill = species)) +
  geom_bar()

ggsave("rg3.pdf")

ggplot(penguins, aes(x = body_mass_g, color = species, fill = species)) +
  geom_density(alpha = 0.5)

ggsave("rg4.pdf")
